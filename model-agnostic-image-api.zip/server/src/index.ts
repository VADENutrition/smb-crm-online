import "dotenv/config";
import express from "express";
import cors from "cors";
import { router } from "./routes.js";

const app = express();
app.use(express.json({ limit: "20mb" }));

const origin = process.env.CORS_ORIGIN || "http://localhost:5173";
app.use(cors({ origin, credentials: true }));

app.use(router);

const port = Number(process.env.PORT || 8080);
app.listen(port, () => {
  console.log(`Model-agnostic Image API listening on http://localhost:${port}`);
  console.log(`Health: http://localhost:${port}/health`);
});
