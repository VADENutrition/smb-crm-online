import PQueue from "p-queue";

export const queue = new PQueue({
  concurrency: 1, // safe default; raise if you have GPU capacity
});

export async function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  return queue.add(fn);
}
