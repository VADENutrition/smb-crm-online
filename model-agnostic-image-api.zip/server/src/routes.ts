import express from "express";
import { generateImageSchema } from "./validation.js";
import { buildProviders, resolveProviderId } from "./providers/index.js";
import { enqueue } from "./queue.js";

const providers = buildProviders();

export const router = express.Router();

router.get("/health", (_req, res) => {
  res.json({
    ok: true,
    providers: Object.fromEntries(
      Object.entries(providers).map(([k, p]) => [k, { configured: p.isConfigured() }])
    )
  });
});

router.post("/api/generate-image", async (req, res) => {
  const parsed = generateImageSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
  }

  const body = parsed.data;
  const providerId = resolveProviderId(body.provider);

  const provider = providers[providerId];
  if (!provider) {
    return res.status(400).json({ error: `Unknown provider: ${providerId}` });
  }
  if (!provider.isConfigured()) {
    return res.status(500).json({ error: `Provider '${providerId}' not configured` });
  }

  try {
    const result = await enqueue(() => provider.generate(body));
    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      error: err?.message || "Generation failed",
      provider: providerId
    });
  }
});
