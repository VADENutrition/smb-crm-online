import { z } from "zod";

export const referenceImageSchema = z.object({
  imageBase64: z.string().min(10),
  weight: z.number().min(0).max(1).optional(),
  type: z.enum(["face", "style", "pose", "body", "other"]).optional()
});

export const generateImageSchema = z.object({
  requestId: z.string().optional(),
  provider: z.enum(["openai", "comfyui", "gemini", "auto"]).optional(),
  model: z.string().optional(),

  prompt: z.string().min(1),
  negativePrompt: z.string().optional(),

  width: z.number().int().min(64).max(4096).optional(),
  height: z.number().int().min(64).max(4096).optional(),
  numImages: z.number().int().min(1).max(10).optional(),

  seed: z.number().int().optional(),
  steps: z.number().int().min(1).max(200).optional(),
  cfgScale: z.number().min(0).max(30).optional(),

  initImageBase64: z.string().optional(),
  maskBase64: z.string().optional(),

  references: z.array(referenceImageSchema).optional(),
  providerOptions: z.record(z.unknown()).optional(),
});
