import { ImageProvider, GenerateImageRequest, GenerateImageResult } from "../types.js";

/**
 * Gemini/Imagen/Vertex integration is intentionally left as a stub because
 * different projects wire it differently (AI Studio vs Vertex, Imagen models, etc).
 *
 * Hook this up to the exact API call you already have in your frontend's
 * services/gemini.ts (move it server-side if you want to hide keys).
 */
export class GeminiStubProvider implements ImageProvider {
  public readonly id = "gemini" as const;

  isConfigured(): boolean {
    return !!process.env.GEMINI_API_KEY;
  }

  async generate(_req: GenerateImageRequest): Promise<GenerateImageResult> {
    throw new Error(
      "Gemini provider is a stub. Wire it to your existing implementation or switch AUTO_PROVIDER=openai/comfyui."
    );
  }
}
