import OpenAI from "openai";
import { ImageProvider, GenerateImageRequest, GenerateImageResult } from "../types.js";

function stripDataPrefix(b64: string): string {
  return b64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, "");
}

export class OpenAIImagesProvider implements ImageProvider {
  public readonly id = "openai" as const;
  private client: OpenAI | null = null;
  private model: string;

  constructor() {
    const apiKey = process.env.OPENAI_API_KEY;
    this.model = process.env.OPENAI_IMAGE_MODEL || "gpt-image-1";
    if (apiKey) this.client = new OpenAI({ apiKey });
  }

  isConfigured(): boolean {
    return !!this.client;
  }

  async generate(req: GenerateImageRequest): Promise<GenerateImageResult> {
    if (!this.client) throw new Error("OpenAI provider not configured: missing OPENAI_API_KEY");

    const size = (() => {
      const w = req.width ?? 1024;
      const h = req.height ?? 1024;
      // OpenAI Images supports certain sizes; if not supported it will error.
      // Keep it simple: map to common sizes.
      const candidates = [
        [1024, 1024],
        [1024, 1536],
        [1536, 1024],
        [512, 512],
      ];
      const best = candidates.reduce((acc, cur) => {
        const d = Math.abs(cur[0]-w) + Math.abs(cur[1]-h);
        const da = Math.abs(acc[0]-w) + Math.abs(acc[1]-h);
        return d < da ? cur : acc;
      }, candidates[0]);
      return `${best[0]}x${best[1]}` as const;
    })();

    // If you want strict identity control, you'll typically do that with open-source.
    // OpenAI image API accepts text prompts + optional input images (for edits/variations),
    // but we keep the core interface consistent and minimal here.

    const response = await this.client.images.generate({
      model: req.model || this.model,
      prompt: req.prompt,
      size,
      n: req.numImages ?? 1
    });

    const images = (response.data || []).map((d: any) => ({
      base64: d.b64_json ? stripDataPrefix(d.b64_json) : undefined,
      url: d.url ?? undefined,
      mimeType: "image/png",
    }));

    return {
      providerUsed: "openai",
      modelUsed: req.model || this.model,
      images,
      raw: process.env.NODE_ENV === "production" ? undefined : response
    };
  }
}
