import { ImageProvider, GenerateImageRequest, GenerateImageResult } from "../types.js";
import fs from "node:fs";
import path from "node:path";

type ComfyHistory = Record<string, any>;

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function httpJson(url: string, init?: RequestInit): Promise<any> {
  const res = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {})
    }
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`ComfyUI HTTP ${res.status}: ${txt || res.statusText}`);
  }
  return res.json();
}

function loadWorkflowJSON(): any {
  const p = process.env.COMFYUI_WORKFLOW_PATH;
  if (!p) return null;
  const abs = path.isAbsolute(p) ? p : path.join(process.cwd(), p);
  if (!fs.existsSync(abs)) return null;
  return JSON.parse(fs.readFileSync(abs, "utf-8"));
}

/**
 * This provider assumes you run ComfyUI locally (or on a GPU server) with a workflow that:
 * - Accepts `prompt`, `negative_prompt`, `width`, `height`, `seed`, `steps`, `cfg`
 * - Produces image output in history
 *
 * We ship a very basic SDXL workflow JSON you can edit at:
 * server/comfyui/workflows/sdxl_basic_api.json
 */
export class ComfyUIProvider implements ImageProvider {
  public readonly id = "comfyui" as const;
  private baseUrl: string;
  private workflow: any;

  constructor() {
    this.baseUrl = process.env.COMFYUI_BASE_URL || "http://127.0.0.1:8188";
    this.workflow = loadWorkflowJSON();
  }

  isConfigured(): boolean {
    return !!this.baseUrl;
  }

  private buildPromptGraph(req: GenerateImageRequest): any {
    if (!this.workflow) {
      throw new Error("COMFYUI_WORKFLOW_PATH not found/invalid. See server/.env.example");
    }

    const graph = structuredClone(this.workflow);

    // Convention used in the shipped workflow:
    // - Node "6" is CLIPTextEncode (positive)
    // - Node "7" is CLIPTextEncode (negative)
    // - Node "5" is EmptyLatentImage (width/height)
    // - Node "3" is KSampler (seed/steps/cfg)
    //
    // If you change the workflow, update these ids accordingly.
    if (graph["6"]?.inputs) graph["6"].inputs.text = req.prompt;
    if (graph["7"]?.inputs) graph["7"].inputs.text = req.negativePrompt || "";
    if (graph["5"]?.inputs) {
      graph["5"].inputs.width = req.width ?? 1024;
      graph["5"].inputs.height = req.height ?? 1024;
      graph["5"].inputs.batch_size = req.numImages ?? 1;
    }
    if (graph["3"]?.inputs) {
      if (typeof req.seed === "number") graph["3"].inputs.seed = req.seed;
      graph["3"].inputs.steps = req.steps ?? 30;
      graph["3"].inputs.cfg = req.cfgScale ?? 6.5;
    }

    // References / face-locking:
    // This is where you'd wire in IP-Adapter / InstantID / ControlNet nodes in your workflow
    // and populate their image inputs. We keep the provider API ready (references[]) but
    // you must add the corresponding nodes in ComfyUI for this to have effect.
    // (We can do this next once you pick IP-Adapter vs InstantID.)

    return graph;
  }

  async generate(req: GenerateImageRequest): Promise<GenerateImageResult> {
    const promptGraph = this.buildPromptGraph(req);

    const submit = await httpJson(`${this.baseUrl}/prompt`, {
      method: "POST",
      body: JSON.stringify({ prompt: promptGraph })
    });

    const promptId = submit?.prompt_id;
    if (!promptId) throw new Error(`ComfyUI did not return prompt_id: ${JSON.stringify(submit)}`);

    // Poll history until outputs exist
    let history: ComfyHistory | null = null;
    for (let i = 0; i < 120; i++) {
      history = await httpJson(`${this.baseUrl}/history/${promptId}`);
      const item = history?.[promptId];
      const hasOutputs = item?.outputs && Object.keys(item.outputs).length > 0;
      if (hasOutputs) break;
      await sleep(500);
    }

    const item = history?.[promptId];
    if (!item?.outputs) {
      throw new Error("Timed out waiting for ComfyUI output. Check ComfyUI console/logs.");
    }

    // Fetch output images from /view
    const images: { url: string; mimeType: string }[] = [];
    for (const nodeId of Object.keys(item.outputs)) {
      const out = item.outputs[nodeId];
      const imgs = out?.images || [];
      for (const img of imgs) {
        // img has filename, subfolder, type
        const params = new URLSearchParams({
          filename: img.filename,
          subfolder: img.subfolder || "",
          type: img.type || "output"
        });
        images.push({
          url: `${this.baseUrl}/view?${params.toString()}`,
          mimeType: "image/png"
        });
      }
    }

    return {
      providerUsed: "comfyui",
      modelUsed: req.model,
      images,
      raw: process.env.NODE_ENV === "production" ? undefined : item
    };
  }
}
