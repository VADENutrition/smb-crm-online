import { ImageProvider, ProviderId } from "../types.js";
import { OpenAIImagesProvider } from "./openai.js";
import { ComfyUIProvider } from "./comfyui.js";
import { GeminiStubProvider } from "./gemini_stub.js";

export function buildProviders(): Record<Exclude<ProviderId, "auto">, ImageProvider> {
  const openai = new OpenAIImagesProvider();
  const comfyui = new ComfyUIProvider();
  const gemini = new GeminiStubProvider();

  return { openai, comfyui, gemini };
}

export function resolveProviderId(requested?: ProviderId): Exclude<ProviderId, "auto"> {
  if (requested && requested !== "auto") return requested;

  const env = (process.env.AUTO_PROVIDER || "openai").toLowerCase().trim();
  if (env === "comfyui") return "comfyui";
  if (env === "gemini") return "gemini";
  return "openai";
}
