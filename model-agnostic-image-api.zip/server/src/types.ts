export type ProviderId = "openai" | "comfyui" | "gemini" | "auto";

export type ReferenceImage = {
  /** base64 (no data: prefix) */
  imageBase64: string;
  /** 0..1 */
  weight?: number;
  /** semantic hint for your pipeline */
  type?: "face" | "style" | "pose" | "body" | "other";
};

export type GenerateImageRequest = {
  requestId?: string;
  provider?: ProviderId;   // "auto" uses env AUTO_PROVIDER
  model?: string;

  prompt: string;
  negativePrompt?: string;

  width?: number;
  height?: number;
  numImages?: number;

  seed?: number;
  steps?: number;
  cfgScale?: number;

  /** Optional img2img */
  initImageBase64?: string;
  /** Optional inpainting */
  maskBase64?: string;

  references?: ReferenceImage[];

  /** Arbitrary provider-specific overrides (kept out of core schema) */
  providerOptions?: Record<string, unknown>;
};

export type GeneratedImage = {
  /** base64 (no data: prefix), if returned inline */
  base64?: string;
  /** URL if provider returns hosted images */
  url?: string;
  /** mime type, e.g. image/png */
  mimeType?: string;
};

export type GenerateImageResult = {
  providerUsed: Exclude<ProviderId, "auto">;
  modelUsed?: string;
  images: GeneratedImage[];
  /** Provider-specific debug info (safe to omit in prod) */
  raw?: unknown;
};

export interface ImageProvider {
  id: Exclude<ProviderId, "auto">;
  isConfigured(): boolean;
  generate(req: GenerateImageRequest): Promise<GenerateImageResult>;
}
