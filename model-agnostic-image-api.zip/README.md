# Model-agnostic Image API (Provider Router)

This is a drop-in backend API that lets your frontend call **one endpoint** while you swap image-generation providers behind the scenes:
- OpenAI Images API
- ComfyUI (local SDXL / FLUX / etc.)
- (Optional) Gemini/Vertex/Imagen stub (wire to your existing call)

## Quick start (Windows)
1) Install Node.js LTS (>=18)
2) Copy `.env.example` to `.env` and fill keys
3) From `server/`:
```powershell
npm install
npm run dev
```
4) Open:
- API: http://localhost:8080/health
- Generate: POST http://localhost:8080/api/generate-image

## What you get
- **Provider interface**: `ImageProvider`
- **Router**: chooses provider via request `provider` or `AUTO_PROVIDER` env var
- **Uniform request/response schema**
- **ComfyUI integration**: submit prompt + poll history
- **OpenAI integration**: `openai` npm client
- **CORS enabled** for local frontend dev

## Notes
- This repo intentionally keeps the queue simple (in-memory). For production, swap to Redis + BullMQ.
- You should still implement your own safety/abuse rules and logging appropriate for your use case.
