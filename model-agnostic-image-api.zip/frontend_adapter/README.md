# Frontend Adapter (optional)

If your existing React app currently calls Gemini directly, you can switch it to call the backend API instead.

1) Copy `apiClient.ts` into your frontend `src/services/apiClient.ts`
2) Replace your existing generation call with `generateImage(...)`

Set your Vite env:
- `VITE_API_BASE_URL=http://localhost:8080`
