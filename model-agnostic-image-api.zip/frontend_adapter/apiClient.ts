export type ProviderId = "openai" | "comfyui" | "gemini" | "auto";

export type ReferenceImage = {
  imageBase64: string; // no data: prefix
  weight?: number;
  type?: "face" | "style" | "pose" | "body" | "other";
};

export type GenerateImageRequest = {
  provider?: ProviderId;
  model?: string;
  prompt: string;
  negativePrompt?: string;
  width?: number;
  height?: number;
  numImages?: number;
  seed?: number;
  steps?: number;
  cfgScale?: number;
  initImageBase64?: string;
  maskBase64?: string;
  references?: ReferenceImage[];
  providerOptions?: Record<string, unknown>;
};

export type GeneratedImage = {
  base64?: string;
  url?: string;
  mimeType?: string;
};

export type GenerateImageResult = {
  providerUsed: Exclude<ProviderId, "auto">;
  modelUsed?: string;
  images: GeneratedImage[];
};

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

export async function generateImage(req: GenerateImageRequest): Promise<GenerateImageResult> {
  const res = await fetch(`${API_BASE}/api/generate-image`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`API ${res.status}: ${txt || res.statusText}`);
  }

  return res.json();
}
